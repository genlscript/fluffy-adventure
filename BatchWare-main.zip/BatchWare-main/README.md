# BATCH MALWARE

## Legal disclaimer:
**Usage of Batch Malware for any harmful intent whatsoever is ILLEGAL**. 

It is YOUR responsibility to obey Hacking ethics and laws of all country. Developers have no liability and are not responsible for any misuse or damage caused by this program.

**DO NOT** use this malware except for testing purpose on your own device (or any other device with prior mutual consent of the owner). Please note that this malware is extremely harmful and deals irreversible damage to your device once activated. Use with caution. You have been warned.

